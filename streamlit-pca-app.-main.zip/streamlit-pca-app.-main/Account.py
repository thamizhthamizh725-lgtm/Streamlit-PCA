import streamlit as st

st.title("👤 Account")

username = st.text_input("Username")
email = st.text_input("Email")

if st.button("Save"):
    st.success("Account details saved successfully!")
