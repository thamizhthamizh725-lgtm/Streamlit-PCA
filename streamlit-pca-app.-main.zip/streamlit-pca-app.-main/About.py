import streamlit as st

st.title("ℹ️ About")

st.write("""
This application is built using **Streamlit**.

Features:
- Multipage navigation
- User posts
- Trending topics
""")
