import streamlit as st

st.set_page_config(page_title="My Streamlit App", layout="wide")

st.title("🚀 Welcome to My Streamlit App")
st.write("""
This is the main page. Use the sidebar to navigate to:
- Home
- Trending
- Your Post
- About
- Account
- PCA Analysis
""")

st.success("Application loaded successfully ✅")
