import streamlit as st

st.title("🔥 Trending")
st.write("Trending topics and popular posts")

trends = ["AI", "Data Science", "Machine Learning", "Web Development"]
for t in trends:
    st.write("•", t)
