import streamlit as st
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

st.set_page_config(page_title="PCA Analysis", layout="wide")
st.title("📊 Principal Component Analysis (PCA)")

# ----------------- Sample CSV -----------------
st.subheader("Download Sample CSV")
sample_data = {
    "Name": ["Alice","Bob","Charlie","David","Eve","Frank","Grace","Henry"],
    "Height": [170,160,175,168,160,180,165,172],
    "Weight": [65,55,70,60,75,58,68,72],
    "Age": [25,24,23,30,27,28,24,26],
    "Score1": [88,78,95,82,91,80,89,93],
    "Score2": [92,85,90,88,94,86,91,95]
}
sample_df = pd.DataFrame(sample_data)
csv = sample_df.to_csv(index=False)
st.download_button(
    label="📥 Download Sample CSV",
    data=csv,
    file_name="sample_data.csv",
    mime="text/csv"
)

# ----------------- Upload CSV -----------------
uploaded_file = st.file_uploader("Upload CSV file for PCA (or use sample CSV)", type=["csv"])

# If user didn't upload, use sample CSV
if uploaded_file is not None:
    df = pd.read_csv(uploaded_file)
else:
    df = sample_df
    st.info("Using built-in sample CSV for PCA")

# ----------------- PCA Analysis -----------------
st.subheader("Original Data")
st.dataframe(df.head())

# Select numeric columns
numeric_df = df.select_dtypes(include=["float64", "int64"])
if numeric_df.shape[1] < 2:
    st.error("❌ Need at least 2 numeric columns for PCA")
else:
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(numeric_df)

    n_components = st.slider(
        "Select number of PCA components",
        1,
        min(5, numeric_df.shape[1]),
        2
    )

    pca = PCA(n_components=n_components)
    pca_result = pca.fit_transform(scaled_data)

    pca_df = pd.DataFrame(
        pca_result,
        columns=[f"PC{i+1}" for i in range(n_components)]
    )

    st.subheader("PCA Result (First 5 Rows)")
    st.dataframe(pca_df.head())

    st.subheader("Explained Variance Ratio")
    st.write(pca.explained_variance_ratio_)

    # Line plot
    fig, ax = plt.subplots()
    ax.plot(pca.explained_variance_ratio_, marker='o', color='blue')
    ax.set_xlabel("Principal Components")
    ax.set_ylabel("Variance Ratio")
    ax.set_title("PCA Explained Variance")
    st.pyplot(fig)

    # 2D scatter plot if >= 2 components
    if n_components >= 2:
        st.subheader("2D Scatter Plot of First 2 PCs")
        fig2, ax2 = plt.subplots()
        ax2.scatter(pca_df["PC1"], pca_df["PC2"], color='green')
        for i, txt in enumerate(df.index):
            ax2.annotate(txt, (pca_df["PC1"][i], pca_df["PC2"][i]))
        ax2.set_xlabel("PC1")
        ax2.set_ylabel("PC2")
        ax2.set_title("PCA 2D Scatter Plot")
        st.pyplot(fig2)
