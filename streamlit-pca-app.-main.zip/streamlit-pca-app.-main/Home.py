import streamlit as st

st.title("🏠 Home")
st.write("Welcome to the Home page")
st.info("This is the main dashboard")
