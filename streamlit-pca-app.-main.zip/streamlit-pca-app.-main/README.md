# streamlit-pca-app.
An interactive Streamlit application for performing Principal Component Analysis (PCA) on any dataset. Upload your CSV file, select numeric columns, choose the number of components, and visualize the results with 2D scatter plots. The app also shows the explained variance ratio for each principal component.
