import streamlit as st

st.title("✍️ Your Post")

post = st.text_area("Write your post here")

if st.button("Submit"):
    if post.strip() == "":
        st.warning("Post cannot be empty")
    else:
        st.success("Post submitted successfully!")
        st.write("### Your Post:")
        st.write(post)
